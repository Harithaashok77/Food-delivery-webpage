import React from 'react'
import Last from '../components/Cart/Last'

const LastPage = () => {
  return (
    <div>
        <Last />
    </div>
  )
}

export default LastPage