import React from 'react'
import '../NightLife/NightLifeStyles.css';

const NIghtLife = () => {
  return (
    <div className='absolute-center'>
      <h1>Coming Soon</h1>
    </div>
  )
}

export default NIghtLife